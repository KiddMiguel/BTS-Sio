<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mes script</title>
    <link rel="stylesheet" href="Untitled-1.css">
</head>
<body>
    <div>
     <header>
         <h1>Mon site Perso</h1>
        <p>Bonjour je me présente je suis <strong>Miguel KIDIMBA</strong> étudiant en prémiere année en informatique. J'ai 19ans célibataire 😂, j'aime  les jeux videos et les manga (<em>comme 60% des gens</em>).</p>
        <nav>
            <ul>
                <li><a href="#Mes compétences">Mes compétences</a></li>
                <li><a href="#Mes passions">Mes passions</a></li>
                <li><a href="#Correspond">Correspond</a></li>
                <li><a href="film.php">Mes Animés</a></li>
            </ul>
        </nav>
     </header>
     <section>
         <div>
            <h1 id="Mes compétences">Mes compétences</h1>
            <ul>
                <li>HTML-CSS</li>
                <li>PHP</li>
                <li>Javascript</li>
                <li>Python</li>
            </ul>
            <p>Et oui j'ai pas mal de compétences 😁 Lol (<em>Je rigole je suis encore en plein apprentissage</em>).</p>
        </div>
        <div>
            <h1 id="Mes passions">Mes passions</h1>
            <p>Je suis passioné de :</p>
            <ul>
                <li>Basketballs</li>
                <li>Jeux videos(<em><strong>Call of duty</strong></em></li>
                <li>Rester cheaz moi</li>
            </ul>
        </div>
        <div id="Correspond">
            <h1>Ce qui me correspond en ce moment</h1>
            <p class="imag"> <img src="664427.jpg" alt="Moi" width="300"></p>
           
        </div>
     </section>
     <footer>
         <h1>FIN</h1>
         <p>HEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE OUI FIN</p>
     </footer>
  </div>
</body>
</html>