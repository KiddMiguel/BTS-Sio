<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ANIME</title>
</head>
<body>
    <div>
        <h1>MES ANIMES</h1>
        <div>
            <table>
                <tr>
                    <th>Genres</th>
                </tr>
                <tr>
                    <td>Action</td>
                    <td><img src="https://fr.web.img6.acsta.net/pictures/21/03/29/15/03/3028114.jpg" width="100"></td>
                    <td><img src="https://static.wikia.nocookie.net/kimetsu-no-yaiba/images/c/c2/Kimetsu_no_Yaiba_-_Affiche_saison_1.png/revision/latest?cb=20200629184534&path-prefix=fr" width="100"></td>

                </tr>
                <tr>
                    <td>Aventure</td>
                </tr>
                <tr>
                    <td>RPG</td>
                </tr>
                <tr>
                    <td>Baston</td>
                </tr>
                <tr>
                    <td>Tellement génial<br> quand se demande </br> si le créateur <br>est humain</td>
                </tr>
            </table>
        </div>
    </div>
</body>
</html>